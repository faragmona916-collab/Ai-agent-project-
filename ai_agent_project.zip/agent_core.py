import os
from openai import OpenAI
from serpapi import GoogleSearch

def run_agent(question: str):
    openai_key=os.getenv("OPENAI_API_KEY")
    serp_key=os.getenv("SERPAPI_API_KEY")

    if not openai_key:
        return "Missing OPENAI_API_KEY"

    client = OpenAI(api_key=openai_key)

    # simple call
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":question}]
    )
    return response.choices[0].message.content
