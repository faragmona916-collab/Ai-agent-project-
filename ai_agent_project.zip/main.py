from fastapi import FastAPI
from agent_core import run_agent

app = FastAPI()

@app.post("/ask")
async def ask(data: dict):
    question = data.get("question", "")
    answer = run_agent(question)
    return {"answer": answer}
