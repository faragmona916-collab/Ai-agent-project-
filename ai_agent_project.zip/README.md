# AI Agent Project

## Endpoints
POST /ask
{"question": "your question"}

## Environment variables
OPENAI_API_KEY
SERPAPI_API_KEY
